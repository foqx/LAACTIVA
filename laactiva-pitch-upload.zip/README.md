# Laactiva — From Waste to the Worth

Interactive Arabic pitch deck with live 3D scenes.

**Live:** https://0ceanmind.github.io/laactiva-pitch/

## Presenting
- `→` / `Space` / `PageDown` next · `←` previous · `F` full screen
- Solution slide: `1`–`4` jump to a step · Features slide: `1`–`5` · Factory slide: `1`–`5` camera views, `T` auto tour, `G` renders gallery
- Move the mouse to the bottom edge to show the slide counter.

## Offline backup
Download this repository as ZIP (Code → Download ZIP), unzip, and double‑click `Laactiva-Offline.html`. No internet needed.
